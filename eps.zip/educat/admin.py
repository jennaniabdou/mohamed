from django.contrib import admin
from educat.models import Type, Module, Visiteurs


# Register your models here.
admin.site.register(Type)

admin.site.register(Module)

admin.site.register(Visiteurs)



